package controller;

import model.Avenger;
import model.AvengerFileIO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.Random;

public class MainServlet extends HttpServlet {

    private List<Avenger> avengers;
    private Avenger anAvenger;
    private int points;
    private int tries;
    private final Random rnd = new Random();

    public static final String AVENGER_FILENAME = "WEB-INF/avengers.csv";

    @Override
    public void init() throws ServletException {
        ServletContext context = getServletContext();
        avengers = AvengerFileIO.loadData(context.getRealPath(AVENGER_FILENAME));
        anAvenger = avengers.get(rnd.nextInt(avengers.size()));
        points = 0;
        tries = 0;
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        boolean displayResults = false;
        if ("/new".equals(action)) {
            // Display new avenger
            anAvenger = avengers.get(rnd.nextInt(avengers.size()));
        } else if ("/who".equals(action)) {
            // Check if answer is correct
            String answer = request.getParameter("answer");
            String correct = "Incorrect";
            if (anAvenger.getName().equals(answer)) {
                points++;
                correct = "Correct";
            }
            tries++;

            request.setAttribute("answer", answer);
            request.setAttribute("correct", correct);
            displayResults = true;
        } else if ("/play".equals(action)) {
            // Re-start
            anAvenger = avengers.get(rnd.nextInt(avengers.size()));
            points = 0;
            tries = 0;
        }
        request.setAttribute("avenger", anAvenger);
        request.setAttribute("points", points);
        request.setAttribute("tries", tries);
        request.setAttribute("displayResults", displayResults);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}

package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class AvengerFileIO {

    /**
     * Load data from file and create list of {@link Avenger}
     *
     * @param file File to read data from
     * @return List of {@link Avenger}
     */
    public static List<Avenger> loadData(String file) {
        List<Avenger> avengers = new ArrayList<>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(file));
            String line;
            boolean skipLine = true;
            while ((line = br.readLine()) != null) {
                if (!skipLine) {
                    StringTokenizer tokenizer = new StringTokenizer(line, ",");
                    Avenger avenger = new Avenger(tokenizer.nextToken(),
                            tokenizer.nextToken().equals("true"),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            Integer.parseInt(tokenizer.nextToken()),
                            tokenizer.nextToken(),
                            tokenizer.nextToken());
                    avengers.add(avenger);
                } else {
                    skipLine = false;
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return avengers;
    }
}

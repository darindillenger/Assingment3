package model;

public class Avenger {
    // Fields with avenger data

    private String name;
    private boolean canFly;
    private Integer intelligence;
    private Integer strength;
    private Integer speed;
    private Integer energy;
    private Integer skill;
    private Integer leadership;
    private Integer charm;
    private Integer luck;
    private String detailUrl;
    private String imageUrl;

    /**
     * Constructor for Avenger class
     */
    public Avenger(String name, boolean canFly, Integer intelligence, Integer strength, Integer speed, Integer energy,
                   Integer skill, Integer leadership, Integer charm, Integer luck, String detailUrl, String imageUrl) {
        this.name = name;
        this.canFly = canFly;
        this.intelligence = intelligence;
        this.strength = strength;
        this.speed = speed;
        this.energy = energy;
        this.skill = skill;
        this.leadership = leadership;
        this.charm = charm;
        this.luck = luck;
        this.detailUrl = detailUrl;
        this.imageUrl = imageUrl;
    }

    // Getters

    public String getName() {
        return name;
    }

    public boolean isCanFly() {
        return canFly;
    }

    public Integer getIntelligence() {
        return intelligence;
    }

    public Integer getStrength() {
        return strength;
    }

    public Integer getSpeed() {
        return speed;
    }

    public Integer getEnergy() {
        return energy;
    }

    public Integer getSkill() {
        return skill;
    }

    public Integer getLeadership() {
        return leadership;
    }

    public Integer getCharm() {
        return charm;
    }

    public Integer getLuck() {
        return luck;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
